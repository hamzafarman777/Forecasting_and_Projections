# Loan Default Scorecard

An end-to-end credit-risk pipeline that builds a probability-of-default (PD) scorecard on a
public loan dataset — **and, more importantly, a case study in detecting and removing data leakage.**

The headline result is deliberately honest: a naive run on this data yields an AUC above 0.95,
but almost all of that is leakage. After the leaks are stripped out, the genuine discriminating
power is roughly **AUC 0.74**. The value of this project is the disciplined process that gets you
to the truthful number instead of the flattering one.

---

## Key findings

| Finding | Detail |
|---|---|
| Leakage #1 | `rate_of_interest`, `Interest_rate_spread`, `Upfront_charges` are missing almost only for defaults — the *absence* of the value encodes the label. Dropped. |
| Leakage #2 | `credit_type == EQUI` defaults 99.99% of the time. A label proxy, not a real bureau effect. Dropped. |
| Leakage #3 | `property_value` missing-value bin still leaks (records with a blank default at near-certainty). Documented as the primary outstanding limitation. |
| Inert feature | `Credit_Score` has a flat ~24.5% default rate across its entire 500–900 range (IV ≈ 0) — almost certainly synthetic. |
| Imputation artifact | Mean-imputing `dtir1`/`LTV` inflates their apparent Information Value; their true contribution is small. |

## Reported performance (held-out test set)

| Metric | Value | Honest read |
|---|---|---|
| AUC-ROC | 0.82 | inflated by the `property_value` MISSING-bin leak |
| Gini | 0.64 | same caveat |
| KS | 0.50 | same caveat |
| Calibration | near-perfect | genuine — probabilities match observed rates per decile |
| **Leakage-adjusted AUC** | **~0.74** | the defensible estimate of true power |

---

## Repository structure

```
loan-default-scorecard/
├── README.md
├── requirements.txt
├── LICENSE
├── .gitignore
├── notebooks/
│   └── Loan_Default_Pipeline.ipynb   # full pipeline: cleaning → EDA → modelling → evaluation
├── data/
│   └── README.md                     # how to obtain Loan_Default.csv (not committed)
├── outputs/                          # generated artifacts (gitignored)
└── docs/
    ├── Step_by_Step_Guide.docx       # what happened at each stage, and why
    └── Model_Validation_Report.docx  # formal independent-review write-up
```

## Quickstart

```bash
# 1. Clone and enter
git clone https://github.com/<your-username>/loan-default-scorecard.git
cd loan-default-scorecard

# 2. Create an environment and install
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 3. Place the dataset
#    Download Loan_Default.csv (see data/README.md) and drop it in data/

# 4. Run the notebook
jupyter notebook notebooks/Loan_Default_Pipeline.ipynb
```

> The notebook reads `Loan_Default.csv` from the working directory by default. If you keep it
> in `data/`, set `DATA_PATH = '../data/Loan_Default.csv'` in the setup cell.

## Pipeline at a glance

1. **Inspect** — shape, dtypes, target balance, and *why* values are missing.
2. **Leakage check #1** — drop the three rate columns.
3. **Clean** — fix LTV decimal errors, impute/drop missing values, cap outliers via IQR winsorizing (not delete).
4. **EDA** — default rates by category; feature distributions by class.
5. **Feature selection** — Information Value, drop IV < 0.02 (and treat IV > 0.5 as a leakage warning).
6. **Leakage check #2** — drop `credit_type`.
7. **Split** — stratified 60/20/20, all preprocessing fit on train only.
8. **Model** — Weight-of-Evidence logistic regression (classic scorecard).
9. **Scale** — convert coefficients to integer points (PDO convention).
10. **Evaluate** — AUC, Gini, KS, calibration, with critical reading of the curves.

## Notes & caveats

- **Single vintage.** All data is 2019, so no time-based validation or drift assessment is possible. A stratified split is used instead.
- **Not deployable as-is.** The `property_value` MISSING-bin leak must be neutralised, and an out-of-time sample obtained, before this could support any real decisioning.
- **Educational use.** The dataset is intended for learning and research, not production credit risk.

## License

MIT — see [LICENSE](LICENSE).
