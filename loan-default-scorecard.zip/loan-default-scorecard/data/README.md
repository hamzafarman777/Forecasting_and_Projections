# Data

The dataset (`Loan_Default.csv`) is **not committed** to this repository — it is left out to
keep the repo lightweight and to avoid redistributing third-party data.

## What you need

- **File:** `Loan_Default.csv`
- **Shape:** 148,670 rows × 34 columns
- **Vintage:** 2019 (single year)
- **Target:** `Status` (1 = default, 0 = non-default), base rate ≈ 24.6%

## How to use it

Place `Loan_Default.csv` in this `data/` folder, then either:

- run the notebook from this folder, or
- set `DATA_PATH = '../data/Loan_Default.csv'` in the notebook's setup cell.

## Note

This is a public educational loan-default dataset. It is intended for learning and research
only — not for production credit decisioning. As documented in the project, it contains
several forms of data leakage that the pipeline deliberately detects and removes.
